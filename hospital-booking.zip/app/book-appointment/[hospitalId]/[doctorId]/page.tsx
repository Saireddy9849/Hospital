"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useParams, useRouter } from "next/navigation"
import { format } from "date-fns"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Clock } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"

// Sample hospital data
const hospitals = {
  1: {
    id: 1,
    name: "City General Hospital",
    location: "123 Main Street, Downtown",
  },
  2: {
    id: 2,
    name: "Memorial Medical Center",
    location: "456 Park Avenue, Uptown",
  },
  3: {
    id: 3,
    name: "Riverside Health Institute",
    location: "789 River Road, Westside",
  },
  4: {
    id: 4,
    name: "Sunshine Medical Center",
    location: "101 Sunshine Blvd, Eastside",
  },
  5: {
    id: 5,
    name: "Greenview Community Hospital",
    location: "202 Green Street, Northside",
  },
}

// Sample doctors data
const doctors = {
  101: {
    id: 101,
    name: "Dr. Sarah Johnson",
    specialty: "Cardiology",
    image: "/placeholder.svg?height=200&width=200",
  },
  102: {
    id: 102,
    name: "Dr. Michael Chen",
    specialty: "Neurology",
    image: "/placeholder.svg?height=200&width=200",
  },
  // Add more doctors as needed
  201: {
    id: 201,
    name: "Dr. Robert Thompson",
    specialty: "Oncology",
    image: "/placeholder.svg?height=200&width=200",
  },
  301: {
    id: 301,
    name: "Dr. Jennifer Lee",
    specialty: "Dermatology",
    image: "/placeholder.svg?height=200&width=200",
  },
  401: {
    id: 401,
    name: "Dr. Amanda Parker",
    specialty: "Gynecology",
    image: "/placeholder.svg?height=200&width=200",
  },
  501: {
    id: 501,
    name: "Dr. Mark Anderson",
    specialty: "Family Medicine",
    image: "/placeholder.svg?height=200&width=200",
  },
}

// Generate time slots
const generateTimeSlots = () => {
  const slots = []
  const startHour = 9 // 9 AM
  const endHour = 17 // 5 PM

  for (let hour = startHour; hour < endHour; hour++) {
    for (let minute = 0; minute < 60; minute += 30) {
      const formattedHour = hour % 12 === 0 ? 12 : hour % 12
      const period = hour < 12 ? "AM" : "PM"
      const formattedMinute = minute === 0 ? "00" : minute
      slots.push(`${formattedHour}:${formattedMinute} ${period}`)
    }
  }

  return slots
}

const timeSlots = generateTimeSlots()

export default function BookAppointment() {
  const params = useParams()
  const router = useRouter()
  const hospitalId = params.hospitalId as string
  const doctorId = params.doctorId as string

  const hospital = hospitals[hospitalId as keyof typeof hospitals]
  const doctor = doctors[doctorId as keyof typeof doctors]

  const [date, setDate] = useState<Date | undefined>(new Date())
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string | null>(null)
  const [showConfirmation, setShowConfirmation] = useState(false)

  if (!hospital || !doctor) {
    return <div className="container mx-auto px-4 py-8">Hospital or doctor not found</div>
  }

  const handleBookAppointment = () => {
    if (!date || !selectedTimeSlot) return

    // Show confirmation modal
    setShowConfirmation(true)
  }

  const confirmAppointment = () => {
    // In a real app, you would save the appointment to a database
    // For now, we'll just redirect to the appointments page
    router.push("/appointments")
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Link href={`/hospitals/${hospitalId}`} className="flex items-center text-blue-600 hover:text-blue-800 mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Hospital
      </Link>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Appointment Details</CardTitle>
              <CardDescription>Book your appointment with</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center mb-4">
                <div className="relative h-16 w-16 mr-4">
                  <Image
                    src={doctor.image || "/placeholder.svg"}
                    alt={doctor.name}
                    fill
                    className="object-cover rounded-full"
                  />
                </div>
                <div>
                  <h3 className="font-medium">{doctor.name}</h3>
                  <p className="text-sm text-gray-600">{doctor.specialty}</p>
                </div>
              </div>
              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-500 mb-1">Hospital</h4>
                <p>{hospital.name}</p>
                <p className="text-sm text-gray-600">{hospital.location}</p>
              </div>
              {date && selectedTimeSlot && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">Selected Time</h4>
                  <p>
                    {format(date, "MMMM d, yyyy")} at {selectedTimeSlot}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Select Date & Time</CardTitle>
              <CardDescription>Choose your preferred appointment slot</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-sm font-medium mb-2">Select Date</h3>
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    disabled={(date) => {
                      // Disable past dates and weekends
                      const today = new Date()
                      today.setHours(0, 0, 0, 0)
                      const day = date.getDay()
                      return date < today || day === 0 || day === 6
                    }}
                    className="border rounded-md"
                  />
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-2">Select Time</h3>
                  <ScrollArea className="h-[300px] border rounded-md p-2">
                    <div className="grid grid-cols-2 gap-2">
                      {timeSlots.map((slot) => (
                        <Button
                          key={slot}
                          variant={selectedTimeSlot === slot ? "default" : "outline"}
                          className={`justify-start ${
                            selectedTimeSlot === slot ? "bg-blue-600 text-white" : "text-gray-700"
                          }`}
                          onClick={() => setSelectedTimeSlot(slot)}
                        >
                          <Clock className="mr-2 h-4 w-4" />
                          {slot}
                        </Button>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={!date || !selectedTimeSlot}
                onClick={handleBookAppointment}
              >
                Book Appointment
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-blue-700 mb-4">Confirm Appointment</h3>
            <p className="mb-4">
              You are about to book an appointment with <strong>{doctor.name}</strong> at{" "}
              <strong>{hospital.name}</strong> on <strong>{format(date as Date, "MMMM d, yyyy")}</strong> at{" "}
              <strong>{selectedTimeSlot}</strong>.
            </p>
            <p className="mb-6">Would you like to confirm this appointment?</p>
            <div className="flex gap-4">
              <Button variant="outline" className="flex-1" onClick={() => setShowConfirmation(false)}>
                Cancel
              </Button>
              <Button className="flex-1 bg-blue-600 hover:bg-blue-700" onClick={confirmAppointment}>
                Confirm Booking
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
