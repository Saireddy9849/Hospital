"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Clock, MapPin } from "lucide-react"
import { format } from "date-fns"

// Sample appointments data
const sampleAppointments = [
  {
    id: 1,
    doctorName: "Dr. Sarah Johnson",
    doctorSpecialty: "Cardiology",
    doctorImage: "/placeholder.svg?height=100&width=100",
    hospitalName: "City General Hospital",
    hospitalLocation: "123 Main Street, Downtown",
    date: new Date(2023, 5, 15, 10, 30),
    status: "upcoming",
  },
  {
    id: 2,
    doctorName: "Dr. Michael Chen",
    doctorSpecialty: "Neurology",
    doctorImage: "/placeholder.svg?height=100&width=100",
    hospitalName: "City General Hospital",
    hospitalLocation: "123 Main Street, Downtown",
    date: new Date(2023, 5, 20, 14, 0),
    status: "upcoming",
  },
  {
    id: 3,
    doctorName: "Dr. Robert Thompson",
    doctorSpecialty: "Oncology",
    doctorImage: "/placeholder.svg?height=100&width=100",
    hospitalName: "Memorial Medical Center",
    hospitalLocation: "456 Park Avenue, Uptown",
    date: new Date(2023, 4, 5, 11, 0),
    status: "completed",
  },
  {
    id: 4,
    doctorName: "Dr. Jennifer Lee",
    doctorSpecialty: "Dermatology",
    doctorImage: "/placeholder.svg?height=100&width=100",
    hospitalName: "Riverside Health Institute",
    hospitalLocation: "789 River Road, Westside",
    date: new Date(2023, 4, 10, 9, 30),
    status: "cancelled",
  },
]

export default function Appointments() {
  const [appointments, setAppointments] = useState(sampleAppointments)
  const [showCancelModal, setShowCancelModal] = useState<number | null>(null)

  const upcomingAppointments = appointments.filter((app) => app.status === "upcoming")
  const completedAppointments = appointments.filter((app) => app.status === "completed")
  const cancelledAppointments = appointments.filter((app) => app.status === "cancelled")

  const handleCancelAppointment = (id: number) => {
    setAppointments(appointments.map((app) => (app.id === id ? { ...app, status: "cancelled" } : app)))
    setShowCancelModal(null)
  }

  const AppointmentCard = ({ appointment }: { appointment: (typeof sampleAppointments)[0] }) => (
    <Card key={appointment.id} className="mb-4">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative h-20 w-20 rounded-full overflow-hidden">
            <Image
              src={appointment.doctorImage || "/placeholder.svg"}
              alt={appointment.doctorName}
              fill
              className="object-cover"
            />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-medium">{appointment.doctorName}</h3>
            <p className="text-gray-600 mb-2">{appointment.doctorSpecialty}</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-4">
              <div className="flex items-center text-gray-600">
                <Calendar className="h-4 w-4 mr-2" />
                <span>{format(appointment.date, "MMMM d, yyyy")}</span>
              </div>
              <div className="flex items-center text-gray-600">
                <Clock className="h-4 w-4 mr-2" />
                <span>{format(appointment.date, "h:mm a")}</span>
              </div>
              <div className="flex items-center text-gray-600 md:col-span-2">
                <MapPin className="h-4 w-4 mr-2" />
                <span>
                  {appointment.hospitalName}, {appointment.hospitalLocation}
                </span>
              </div>
            </div>
          </div>

          {appointment.status === "upcoming" && (
            <div className="flex flex-col gap-2 mt-4 md:mt-0">
              <Button variant="outline" className="text-blue-600 border-blue-600 hover:bg-blue-50">
                Reschedule
              </Button>
              <Button
                variant="outline"
                className="text-red-600 border-red-600 hover:bg-red-50"
                onClick={() => setShowCancelModal(appointment.id)}
              >
                Cancel
              </Button>
            </div>
          )}

          {appointment.status === "completed" && (
            <div className="flex flex-col gap-2 mt-4 md:mt-0">
              <Button className="bg-blue-600 hover:bg-blue-700">Book Again</Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-blue-700 mb-6">My Appointments</h1>

      <Tabs defaultValue="upcoming">
        <TabsList className="w-full mb-6">
          <TabsTrigger value="upcoming" className="flex-1">
            Upcoming ({upcomingAppointments.length})
          </TabsTrigger>
          <TabsTrigger value="completed" className="flex-1">
            Completed ({completedAppointments.length})
          </TabsTrigger>
          <TabsTrigger value="cancelled" className="flex-1">
            Cancelled ({cancelledAppointments.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming">
          {upcomingAppointments.length > 0 ? (
            upcomingAppointments.map((appointment) => (
              <AppointmentCard key={appointment.id} appointment={appointment} />
            ))
          ) : (
            <div className="text-center py-12">
              <h3 className="text-xl font-medium text-gray-700 mb-2">No upcoming appointments</h3>
              <p className="text-gray-600 mb-6">You don't have any scheduled appointments.</p>
              <Button asChild className="bg-blue-600 hover:bg-blue-700">
                <Link href="/hospitals">Book an Appointment</Link>
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="completed">
          {completedAppointments.length > 0 ? (
            completedAppointments.map((appointment) => (
              <AppointmentCard key={appointment.id} appointment={appointment} />
            ))
          ) : (
            <div className="text-center py-12">
              <h3 className="text-xl font-medium text-gray-700">No completed appointments</h3>
              <p className="text-gray-600">Your completed appointments will appear here.</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="cancelled">
          {cancelledAppointments.length > 0 ? (
            cancelledAppointments.map((appointment) => (
              <AppointmentCard key={appointment.id} appointment={appointment} />
            ))
          ) : (
            <div className="text-center py-12">
              <h3 className="text-xl font-medium text-gray-700">No cancelled appointments</h3>
              <p className="text-gray-600">Your cancelled appointments will appear here.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Cancel Confirmation Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-red-600 mb-4">Cancel Appointment</h3>
            <p className="mb-6">Are you sure you want to cancel this appointment? This action cannot be undone.</p>
            <div className="flex gap-4">
              <Button variant="outline" className="flex-1" onClick={() => setShowCancelModal(null)}>
                No, Keep It
              </Button>
              <Button
                className="flex-1 bg-red-600 hover:bg-red-700"
                onClick={() => handleCancelAppointment(showCancelModal)}
              >
                Yes, Cancel
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
