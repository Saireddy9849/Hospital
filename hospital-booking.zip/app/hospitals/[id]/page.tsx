"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useParams } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft } from "lucide-react"

// Sample hospital data
const hospitals = {
  1: {
    id: 1,
    name: "City General Hospital",
    location: "123 Main Street, Downtown",
    image: "/placeholder.svg?height=300&width=800",
    about:
      "City General Hospital is a leading healthcare provider with state-of-the-art facilities and a team of experienced medical professionals dedicated to providing the highest quality of care to patients.",
  },
  2: {
    id: 2,
    name: "Memorial Medical Center",
    location: "456 Park Avenue, Uptown",
    image: "/placeholder.svg?height=300&width=800",
    about:
      "Memorial Medical Center is committed to excellence in healthcare, offering comprehensive medical services with a focus on patient-centered care and innovative treatments.",
  },
  3: {
    id: 3,
    name: "Riverside Health Institute",
    location: "789 River Road, Westside",
    image: "/placeholder.svg?height=300&width=800",
    about:
      "Riverside Health Institute combines cutting-edge technology with compassionate care to address a wide range of health concerns, from routine check-ups to complex medical conditions.",
  },
  4: {
    id: 4,
    name: "Sunshine Medical Center",
    location: "101 Sunshine Blvd, Eastside",
    image: "/placeholder.svg?height=300&width=800",
    about:
      "Sunshine Medical Center is dedicated to improving the health and well-being of the communities we serve through high-quality, cost-effective healthcare services.",
  },
  5: {
    id: 5,
    name: "Greenview Community Hospital",
    location: "202 Green Street, Northside",
    image: "/placeholder.svg?height=300&width=800",
    about:
      "Greenview Community Hospital is a community-focused healthcare facility providing accessible, comprehensive medical services to meet the diverse needs of our patients.",
  },
}

// Sample doctors data
const doctors = {
  1: [
    {
      id: 101,
      name: "Dr. Sarah Johnson",
      specialty: "Cardiology",
      experience: "15 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, Harvard Medical School",
      treatments: ["Heart Disease", "Hypertension", "Arrhythmia", "Coronary Artery Disease"],
      about:
        "Dr. Johnson is a board-certified cardiologist specializing in preventive cardiology and heart disease management.",
    },
    {
      id: 102,
      name: "Dr. Michael Chen",
      specialty: "Neurology",
      experience: "12 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, Johns Hopkins University",
      treatments: ["Stroke", "Epilepsy", "Multiple Sclerosis", "Parkinson's Disease"],
      about: "Dr. Chen is an expert in neurological disorders with a focus on stroke prevention and treatment.",
    },
    {
      id: 103,
      name: "Dr. Emily Rodriguez",
      specialty: "Orthopedics",
      experience: "10 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, Stanford University",
      treatments: ["Joint Replacement", "Sports Injuries", "Fractures", "Arthritis"],
      about: "Dr. Rodriguez specializes in minimally invasive orthopedic procedures and sports medicine.",
    },
    {
      id: 104,
      name: "Dr. James Wilson",
      specialty: "Internal Medicine",
      experience: "18 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, Yale University",
      treatments: ["Preventive Care", "Chronic Disease Management", "Geriatric Medicine", "Diabetes"],
      about: "Dr. Wilson is dedicated to comprehensive primary care and managing complex medical conditions.",
    },
  ],
  2: [
    {
      id: 201,
      name: "Dr. Robert Thompson",
      specialty: "Oncology",
      experience: "20 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, University of Pennsylvania",
      treatments: ["Cancer Screening", "Chemotherapy", "Immunotherapy", "Targeted Therapy"],
      about:
        "Dr. Thompson is a renowned oncologist with expertise in innovative cancer treatments and clinical research.",
    },
    {
      id: 202,
      name: "Dr. Lisa Martinez",
      specialty: "Pediatrics",
      experience: "14 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, Columbia University",
      treatments: ["Child Development", "Pediatric Immunizations", "Childhood Illnesses", "Adolescent Medicine"],
      about: "Dr. Martinez provides compassionate care for children from infancy through adolescence.",
    },
    {
      id: 203,
      name: "Dr. David Kim",
      specialty: "Surgery",
      experience: "16 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, Duke University",
      treatments: ["General Surgery", "Minimally Invasive Surgery", "Hernia Repair", "Gallbladder Surgery"],
      about: "Dr. Kim specializes in advanced surgical techniques with a focus on minimizing recovery time.",
    },
  ],
  3: [
    {
      id: 301,
      name: "Dr. Jennifer Lee",
      specialty: "Dermatology",
      experience: "11 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, University of California, San Francisco",
      treatments: ["Skin Cancer", "Acne", "Eczema", "Psoriasis"],
      about: "Dr. Lee is an expert in medical and cosmetic dermatology, treating a wide range of skin conditions.",
    },
    {
      id: 302,
      name: "Dr. Thomas Wright",
      specialty: "Ophthalmology",
      experience: "13 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, Washington University",
      treatments: ["Cataract Surgery", "Glaucoma", "Diabetic Eye Disease", "LASIK"],
      about: "Dr. Wright is dedicated to preserving and improving vision through advanced eye care treatments.",
    },
    {
      id: 303,
      name: "Dr. Rachel Green",
      specialty: "Psychiatry",
      experience: "9 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, University of Michigan",
      treatments: ["Depression", "Anxiety", "Bipolar Disorder", "PTSD"],
      about: "Dr. Green provides compassionate mental health care with a focus on holistic treatment approaches.",
    },
  ],
  4: [
    {
      id: 401,
      name: "Dr. Amanda Parker",
      specialty: "Gynecology",
      experience: "17 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, Northwestern University",
      treatments: ["Women's Health", "Prenatal Care", "Menopause Management", "Gynecological Surgery"],
      about: "Dr. Parker is committed to providing comprehensive women's healthcare throughout all stages of life.",
    },
    {
      id: 402,
      name: "Dr. Richard Brown",
      specialty: "Urology",
      experience: "19 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, Emory University",
      treatments: ["Prostate Health", "Kidney Stones", "Urinary Incontinence", "Erectile Dysfunction"],
      about:
        "Dr. Brown specializes in urological conditions affecting both men and women, with expertise in minimally invasive procedures.",
    },
    {
      id: 403,
      name: "Dr. Susan Taylor",
      specialty: "ENT",
      experience: "15 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, University of Chicago",
      treatments: ["Sinus Disorders", "Hearing Loss", "Voice Disorders", "Sleep Apnea"],
      about: "Dr. Taylor treats conditions of the ear, nose, and throat with a focus on improving quality of life.",
    },
  ],
  5: [
    {
      id: 501,
      name: "Dr. Mark Anderson",
      specialty: "Family Medicine",
      experience: "22 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, University of Wisconsin",
      treatments: ["Preventive Care", "Chronic Disease Management", "Pediatric Care", "Geriatric Medicine"],
      about:
        "Dr. Anderson provides comprehensive primary care for patients of all ages, focusing on preventive medicine.",
    },
    {
      id: 502,
      name: "Dr. Patricia Nelson",
      specialty: "Internal Medicine",
      experience: "16 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, Vanderbilt University",
      treatments: ["Adult Primary Care", "Chronic Disease Management", "Preventive Medicine", "Geriatrics"],
      about:
        "Dr. Nelson specializes in adult medicine with an emphasis on preventive care and managing complex conditions.",
    },
    {
      id: 503,
      name: "Dr. Kevin Harris",
      specialty: "Rehabilitation",
      experience: "14 years",
      image: "/placeholder.svg?height=200&width=200",
      education: "MD, University of Pittsburgh",
      treatments: ["Physical Therapy", "Occupational Therapy", "Speech Therapy", "Pain Management"],
      about:
        "Dr. Harris helps patients recover from injuries and surgeries, focusing on restoring function and mobility.",
    },
  ],
}

export default function HospitalDetails() {
  const params = useParams()
  const hospitalId = params.id as string
  const hospital = hospitals[hospitalId as keyof typeof hospitals]
  const hospitalDoctors = doctors[hospitalId as keyof typeof doctors] || []
  const [selectedDoctor, setSelectedDoctor] = useState(null)

  if (!hospital) {
    return <div className="container mx-auto px-4 py-8">Hospital not found</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Link href="/hospitals" className="flex items-center text-blue-600 hover:text-blue-800 mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Hospitals
      </Link>

      <div className="mb-8">
        <div className="relative h-64 w-full mb-6 rounded-lg overflow-hidden">
          <Image src={hospital.image || "/placeholder.svg"} alt={hospital.name} fill className="object-cover" />
        </div>
        <h1 className="text-3xl font-bold text-blue-700 mb-2">{hospital.name}</h1>
        <p className="text-gray-600 mb-4">{hospital.location}</p>
        <p className="text-gray-700">{hospital.about}</p>
      </div>

      <h2 className="text-2xl font-bold text-blue-700 mb-6">Our Doctors</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {hospitalDoctors.map((doctor) => (
          <Card key={doctor.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative h-48 w-full">
              <Image src={doctor.image || "/placeholder.svg"} alt={doctor.name} fill className="object-cover" />
            </div>
            <CardHeader>
              <CardTitle>{doctor.name}</CardTitle>
              <CardDescription>
                {doctor.specialty} • {doctor.experience} experience
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-700 mb-2">{doctor.education}</p>
              <Button
                variant="outline"
                className="w-full text-blue-600 border-blue-600 hover:bg-blue-50"
                onClick={() => setSelectedDoctor(doctor)}
              >
                View Profile
              </Button>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                <Link href={`/book-appointment/${hospital.id}/${doctor.id}`}>Book Appointment</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {selectedDoctor && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="text-xl font-bold text-blue-700">{selectedDoctor.name}</h3>
              <Button variant="ghost" size="sm" onClick={() => setSelectedDoctor(null)}>
                ✕
              </Button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-8rem)]">
              <div className="flex flex-col md:flex-row gap-6 mb-6">
                <div className="relative h-48 w-48 mx-auto md:mx-0">
                  <Image
                    src={selectedDoctor.image || "/placeholder.svg"}
                    alt={selectedDoctor.name}
                    fill
                    className="object-cover rounded-lg"
                  />
                </div>
                <div className="flex-1">
                  <p className="text-lg font-medium text-gray-900 mb-1">{selectedDoctor.specialty}</p>
                  <p className="text-gray-600 mb-4">
                    {selectedDoctor.experience} experience • {selectedDoctor.education}
                  </p>
                  <p className="text-gray-700 mb-4">{selectedDoctor.about}</p>
                </div>
              </div>

              <Tabs defaultValue="treatments">
                <TabsList className="w-full">
                  <TabsTrigger value="treatments" className="flex-1">
                    Treatments
                  </TabsTrigger>
                  <TabsTrigger value="education" className="flex-1">
                    Education & Experience
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="treatments" className="mt-4">
                  <h4 className="text-lg font-medium mb-3">Conditions Treated</h4>
                  <ScrollArea className="h-48 border rounded-md p-4">
                    <ul className="space-y-2">
                      {selectedDoctor.treatments.map((treatment) => (
                        <li key={treatment} className="flex items-center">
                          <Badge className="mr-2 bg-blue-100 text-blue-700 hover:bg-blue-100">•</Badge>
                          {treatment}
                        </li>
                      ))}
                    </ul>
                  </ScrollArea>
                </TabsContent>
                <TabsContent value="education" className="mt-4">
                  <h4 className="text-lg font-medium mb-3">Education</h4>
                  <p className="mb-4">{selectedDoctor.education}</p>
                  <h4 className="text-lg font-medium mb-3">Experience</h4>
                  <p>{selectedDoctor.experience} of clinical practice</p>
                </TabsContent>
              </Tabs>
            </div>
            <div className="p-4 border-t bg-gray-50">
              <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                <Link href={`/book-appointment/${hospital.id}/${selectedDoctor.id}`}>Book Appointment</Link>
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
