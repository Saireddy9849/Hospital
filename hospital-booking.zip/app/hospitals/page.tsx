"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

// Sample hospital data
const hospitals = [
  {
    id: 1,
    name: "City General Hospital",
    location: "123 Main Street, Downtown",
    specialties: ["Cardiology", "Neurology", "Orthopedics"],
    rating: 4.8,
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 2,
    name: "Memorial Medical Center",
    location: "456 Park Avenue, Uptown",
    specialties: ["Oncology", "Pediatrics", "Surgery"],
    rating: 4.6,
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 3,
    name: "Riverside Health Institute",
    location: "789 River Road, Westside",
    specialties: ["Dermatology", "Ophthalmology", "Psychiatry"],
    rating: 4.7,
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 4,
    name: "Sunshine Medical Center",
    location: "101 Sunshine Blvd, Eastside",
    specialties: ["Gynecology", "Urology", "ENT"],
    rating: 4.5,
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 5,
    name: "Greenview Community Hospital",
    location: "202 Green Street, Northside",
    specialties: ["Family Medicine", "Internal Medicine", "Rehabilitation"],
    rating: 4.4,
    image: "/placeholder.svg?height=200&width=300",
  },
]

export default function Hospitals() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredHospitals = hospitals.filter(
    (hospital) =>
      hospital.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      hospital.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      hospital.specialties.some((specialty) => specialty.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-blue-700 mb-6">Find a Hospital</h1>

      <div className="relative mb-8">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        <Input
          type="text"
          placeholder="Search by hospital name, location, or specialty..."
          className="pl-10"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredHospitals.map((hospital) => (
          <Card key={hospital.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative h-48 w-full">
              <Image src={hospital.image || "/placeholder.svg"} alt={hospital.name} fill className="object-cover" />
            </div>
            <CardHeader>
              <CardTitle>{hospital.name}</CardTitle>
              <CardDescription>{hospital.location}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <p className="text-sm text-gray-500 mb-1">Specialties:</p>
                <div className="flex flex-wrap gap-2">
                  {hospital.specialties.map((specialty) => (
                    <span key={specialty} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                      {specialty}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex items-center">
                <span className="text-yellow-500 mr-1">★</span>
                <span className="font-medium">{hospital.rating}</span>
                <span className="text-gray-500 text-sm ml-1">/5</span>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                <Link href={`/hospitals/${hospital.id}`}>View Doctors</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}
