export default function About() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-blue-700 mb-6">About MediBook</h1>

        <div className="prose max-w-none">
          <p className="text-lg mb-6">
            MediBook is a comprehensive hospital appointment booking system designed to simplify the process of finding
            and booking appointments with healthcare professionals.
          </p>

          <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-4">Our Mission</h2>
          <p className="mb-6">
            Our mission is to make healthcare more accessible by connecting patients with the right doctors at the right
            time. We believe that everyone deserves easy access to quality healthcare, and our platform is designed to
            remove barriers and streamline the appointment booking process.
          </p>

          <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-4">How It Works</h2>
          <ol className="list-decimal pl-6 mb-6 space-y-2">
            <li>Create an account and complete your patient profile</li>
            <li>Browse through our network of hospitals and healthcare providers</li>
            <li>View detailed profiles of doctors, including their specialties and experience</li>
            <li>Select a convenient date and time for your appointment</li>
            <li>Receive confirmation and reminders for your upcoming appointments</li>
            <li>Manage all your appointments in one place</li>
          </ol>

          <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-4">Our Partners</h2>
          <p className="mb-6">
            We work with a wide network of hospitals, clinics, and healthcare providers to offer you the best options
            for your healthcare needs. Our partners are carefully selected based on their reputation, quality of care,
            and patient satisfaction.
          </p>

          <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-4">Privacy & Security</h2>
          <p className="mb-6">
            We take your privacy and the security of your medical information seriously. All data transmitted through
            our platform is encrypted, and we adhere to strict privacy policies to ensure your information remains
            confidential.
          </p>

          <h2 className="text-2xl font-semibold text-blue-700 mt-8 mb-4">Contact Us</h2>
          <p className="mb-2">If you have any questions or need assistance, please don't hesitate to contact us:</p>
          <ul className="list-disc pl-6 mb-6 space-y-1">
            <li>Email: support@medibook.com</li>
            <li>Phone: (123) 456-7890</li>
            <li>Address: 123 Healthcare Avenue, Medical District, City</li>
          </ul>

          <p className="mt-8 text-gray-600 italic">MediBook - Your health, our priority.</p>
        </div>
      </div>
    </div>
  )
}
