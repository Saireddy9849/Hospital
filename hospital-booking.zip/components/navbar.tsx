"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <nav className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold text-blue-700">
              MediBook
            </Link>
          </div>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-4">
            <Link href="/" className="text-gray-700 hover:text-blue-600 px-3 py-2">
              Home
            </Link>
            <Link href="/hospitals" className="text-gray-700 hover:text-blue-600 px-3 py-2">
              Hospitals
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-blue-600 px-3 py-2">
              About
            </Link>
            <Link href="/appointments" className="text-gray-700 hover:text-blue-600 px-3 py-2">
              My Appointments
            </Link>
            <Button asChild size="sm" className="ml-4 bg-blue-600 hover:bg-blue-700">
              <Link href="/signin">Sign In</Link>
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-blue-600 focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-2">
            <Link
              href="/"
              className="block text-gray-700 hover:text-blue-600 px-3 py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              href="/hospitals"
              className="block text-gray-700 hover:text-blue-600 px-3 py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Hospitals
            </Link>
            <Link
              href="/about"
              className="block text-gray-700 hover:text-blue-600 px-3 py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </Link>
            <Link
              href="/appointments"
              className="block text-gray-700 hover:text-blue-600 px-3 py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              My Appointments
            </Link>
            <div className="pt-2">
              <Button asChild size="sm" className="w-full bg-blue-600 hover:bg-blue-700">
                <Link href="/signin">Sign In</Link>
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
